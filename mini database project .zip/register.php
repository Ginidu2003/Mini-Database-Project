<?php
// Step 1: Connect to database
$servername = "localhost";
$username = "root";    // default username
$password = "";        // default password (empty)
$dbname = "BusCompanyDB";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Step 2: Get form data
$passenger_id = $_POST['passenger_id'];
$name = $_POST['name'];
$contact = $_POST['contact'];
$email = $_POST['email'];

// Step 3: Insert into database
$sql = "INSERT INTO passenger (passenger_id, name, contact, email) 
VALUES ('$passenger_id', '$name', '$contact', '$email')";

if ($conn->query($sql) === TRUE) {
  echo "Registration successful!";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
