<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "BusCompanyDB";  // Make sure this matches your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from form
$passenger_id = $_POST['passenger_id'];
$start_station_id = $_POST['start_station_id'];
$end_station_id = $_POST['end_station_id'];
$booking_date = $_POST['booking_date'];
$no_of_seats = $_POST['no_of_seats'];


// Find fare from fare table (consider both directions)
$fare_sql = "SELECT fare_amount FROM Fare 
             WHERE (start_station_id = '$start_station_id' AND end_station_id = '$end_station_id') 
             OR (start_station_id = '$end_station_id' AND end_station_id = '$start_station_id')";
             
$fare_result = $conn->query($fare_sql);

if ($fare_result->num_rows > 0) {
    $row = $fare_result->fetch_assoc();
    $fare_amount = $row['fare_amount'];

    // Now calculate total fare
    $fare_amount = $fare_amount * $no_of_seats;
} else {
    echo "Fare not found for this route.";
    exit();
}





// Insert into booking table
$sql = "INSERT INTO booking (passenger_id, start_station_id, end_station_id,  no_of_seats,booking_date,fare_amount) VALUES ('$passenger_id', '$start_station_id', '$end_station_id','$no_of_seats', '$booking_date',$fare_amount )";

if ($conn->query($sql) === TRUE) {
    echo "Reservation successful!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
