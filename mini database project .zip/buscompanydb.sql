-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 09, 2025 at 09:31 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buscompanydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `assistant`
--

CREATE TABLE `assistant` (
  `assistant_id` int(10) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `contact` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assistant`
--

INSERT INTO `assistant` (`assistant_id`, `name`, `birth_date`, `contact`) VALUES
(1, 'pasindu himantha', '1995-04-11', 0),
(2, 'isuru sachinthana', '1998-06-10', 0),
(10, 'akila shamnaka', '1996-08-24', 713569875);

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(11) NOT NULL,
  `passenger_id` varchar(20) DEFAULT NULL,
  `start_station_id` int(10) DEFAULT NULL,
  `end_station_id` int(10) DEFAULT NULL,
  `no_of_seats` int(2) NOT NULL,
  `booking_date` date DEFAULT NULL,
  `fare_amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `passenger_id`, `start_station_id`, `end_station_id`, `no_of_seats`, `booking_date`, `fare_amount`) VALUES
(18, 'pasindu2003', 50, 74, 6, '2025-04-29', '900.00'),
(19, 'thejan2003', 74, 50, 4, '2025-04-29', '600.00'),
(20, 'isuri@2003', 74, 50, 2, '2025-04-28', '300.00'),
(21, 'isuri@2003', 300, 350, 9, '2025-04-29', '900.00'),
(22, 'pasindu2003', 300, 350, 5, '2025-04-30', '500.00'),
(23, 'pasindu2003', 350, 300, 6, '2025-04-28', '600.00'),
(24, 'thejan2003', 300, 350, 6, '2025-04-27', '600.00'),
(25, 'ginidu2004', 350, 300, 2, '2025-11-30', '200.00'),
(26, 'saman2003', 350, 300, 2, '2025-11-20', '200.00');

-- --------------------------------------------------------

--
-- Table structure for table `bus`
--

CREATE TABLE `bus` (
  `bus_id` int(10) NOT NULL,
  `plate_number` varchar(50) NOT NULL,
  `capacity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bus`
--

INSERT INTO `bus` (`bus_id`, `plate_number`, `capacity`) VALUES
(1, 'ABC8050', 52),
(2, 'CDE2301', 50),
(3, 'JHG5635', 50);

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE `driver` (
  `driver_id` int(10) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `licence_no` varchar(20) NOT NULL,
  `contact` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`driver_id`, `name`, `birth_date`, `licence_no`, `contact`) VALUES
(1, 'kaveen chamodya', '1991-04-25', 'A238448', 0),
(2, 'thejan chamikara', '2000-06-10', 'B9787833', 0);

-- --------------------------------------------------------

--
-- Table structure for table `fare`
--

CREATE TABLE `fare` (
  `start_station_id` int(10) NOT NULL,
  `end_station_id` int(10) NOT NULL,
  `fare_amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fare`
--

INSERT INTO `fare` (`start_station_id`, `end_station_id`, `fare_amount`) VALUES
(50, 74, '150.00'),
(300, 350, '100.00');

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

CREATE TABLE `passenger` (
  `passenger_id` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`passenger_id`, `name`, `contact`, `email`) VALUES
('', '', '', ''),
('Apsara2003', 'apsara arachchige', '0775958952', 'apsara@gmail.com'),
('ginidu2003', 'Ginidu Sithumal', '0775958950', 'ginidusampath1@gmail.com'),
('ginidu2004', 'Ginidu Sithumal', '0775958950', 'ginidusampath1@gmail.com'),
('isuri@2003', 'isuri sachinthana', '0756985326', 'isuru@gmail.com'),
('kaveen@2003', 'kaveen chamodya', '0741265389', 'kaveen@gmail.com'),
('pasindu2003', 'pasindu himantha', '0745698365', 'pasindu@gmail.com'),
('saman2003', 'saman kumara', '0771032891', 'saman@gmail.com'),
('thejan2003', 'thejan chamikara', '0765983235', 'thejan@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE `route` (
  `route_id` varchar(20) NOT NULL,
  `start_station_id` int(10) NOT NULL,
  `end_station_id` int(10) NOT NULL,
  `total_distance_KM` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`route_id`, `start_station_id`, `end_station_id`, `total_distance_KM`) VALUES
('300-350', 300, 350, 44),
('50-74', 50, 74, 102);

-- --------------------------------------------------------

--
-- Table structure for table `routestation`
--

CREATE TABLE `routestation` (
  `route_id` varchar(20) NOT NULL,
  `station_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `station`
--

CREATE TABLE `station` (
  `station_id` int(10) NOT NULL,
  `station_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `station`
--

INSERT INTO `station` (`station_id`, `station_name`) VALUES
(50, 'colombo'),
(74, 'kandy'),
(300, 'Galle'),
(350, 'Matara');

-- --------------------------------------------------------

--
-- Table structure for table `ticketreport`
--

CREATE TABLE `ticketreport` (
  `report_id` int(10) NOT NULL,
  `trip_id` int(10) DEFAULT NULL,
  `assistant_id` int(10) DEFAULT NULL,
  `total_tickets_sold` int(3) DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `report_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticketreport`
--

INSERT INTO `ticketreport` (`report_id`, `trip_id`, `assistant_id`, `total_tickets_sold`, `total_amount`, `report_date`) VALUES
(1, 1, 1, 50, '20000.00', '2025-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `trip`
--

CREATE TABLE `trip` (
  `trip_id` int(10) NOT NULL,
  `route_id` varchar(20) NOT NULL,
  `bus_id` int(10) NOT NULL,
  `driver_id` int(10) NOT NULL,
  `assistant_id` int(10) NOT NULL,
  `trip_date` date DEFAULT NULL,
  `departure` time(6) NOT NULL,
  `arrival` time(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trip`
--

INSERT INTO `trip` (`trip_id`, `route_id`, `bus_id`, `driver_id`, `assistant_id`, `trip_date`, `departure`, `arrival`) VALUES
(1, '300-350', 1, 1, 1, '2025-04-30', '00:00:00.000000', '00:00:00.000000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assistant`
--
ALTER TABLE `assistant`
  ADD PRIMARY KEY (`assistant_id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `start_station_id` (`start_station_id`),
  ADD KEY `end_station_id` (`end_station_id`),
  ADD KEY `booking_ibfk_2` (`passenger_id`);

--
-- Indexes for table `bus`
--
ALTER TABLE `bus`
  ADD PRIMARY KEY (`bus_id`);

--
-- Indexes for table `driver`
--
ALTER TABLE `driver`
  ADD PRIMARY KEY (`driver_id`);

--
-- Indexes for table `fare`
--
ALTER TABLE `fare`
  ADD PRIMARY KEY (`start_station_id`,`end_station_id`);

--
-- Indexes for table `passenger`
--
ALTER TABLE `passenger`
  ADD PRIMARY KEY (`passenger_id`);

--
-- Indexes for table `route`
--
ALTER TABLE `route`
  ADD PRIMARY KEY (`route_id`),
  ADD KEY `start_station_id` (`start_station_id`),
  ADD KEY `end_station_id` (`end_station_id`);

--
-- Indexes for table `routestation`
--
ALTER TABLE `routestation`
  ADD PRIMARY KEY (`route_id`,`station_id`),
  ADD KEY `station_id` (`station_id`);

--
-- Indexes for table `station`
--
ALTER TABLE `station`
  ADD PRIMARY KEY (`station_id`);

--
-- Indexes for table `ticketreport`
--
ALTER TABLE `ticketreport`
  ADD PRIMARY KEY (`report_id`),
  ADD UNIQUE KEY `trip_id` (`trip_id`),
  ADD KEY `assistant_id` (`assistant_id`);

--
-- Indexes for table `trip`
--
ALTER TABLE `trip`
  ADD PRIMARY KEY (`trip_id`),
  ADD KEY `bus_id` (`bus_id`),
  ADD KEY `driver_id` (`driver_id`),
  ADD KEY `assistant_id` (`assistant_id`),
  ADD KEY `trip_ibfk_1` (`route_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `ticketreport`
--
ALTER TABLE `ticketreport`
  MODIFY `report_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`passenger_id`) REFERENCES `passenger` (`passenger_id`),
  ADD CONSTRAINT `booking_ibfk_3` FOREIGN KEY (`start_station_id`) REFERENCES `station` (`station_id`),
  ADD CONSTRAINT `booking_ibfk_4` FOREIGN KEY (`end_station_id`) REFERENCES `station` (`station_id`);

--
-- Constraints for table `route`
--
ALTER TABLE `route`
  ADD CONSTRAINT `route_ibfk_1` FOREIGN KEY (`start_station_id`) REFERENCES `station` (`station_id`),
  ADD CONSTRAINT `route_ibfk_2` FOREIGN KEY (`end_station_id`) REFERENCES `station` (`station_id`);

--
-- Constraints for table `routestation`
--
ALTER TABLE `routestation`
  ADD CONSTRAINT `routestation_ibfk_1` FOREIGN KEY (`route_id`) REFERENCES `route` (`route_id`),
  ADD CONSTRAINT `routestation_ibfk_2` FOREIGN KEY (`station_id`) REFERENCES `station` (`station_id`);

--
-- Constraints for table `ticketreport`
--
ALTER TABLE `ticketreport`
  ADD CONSTRAINT `ticketreport_ibfk_1` FOREIGN KEY (`trip_id`) REFERENCES `trip` (`trip_id`),
  ADD CONSTRAINT `ticketreport_ibfk_2` FOREIGN KEY (`assistant_id`) REFERENCES `assistant` (`assistant_id`);

--
-- Constraints for table `trip`
--
ALTER TABLE `trip`
  ADD CONSTRAINT `trip_ibfk_1` FOREIGN KEY (`route_id`) REFERENCES `route` (`route_id`),
  ADD CONSTRAINT `trip_ibfk_2` FOREIGN KEY (`bus_id`) REFERENCES `bus` (`bus_id`),
  ADD CONSTRAINT `trip_ibfk_3` FOREIGN KEY (`driver_id`) REFERENCES `driver` (`driver_id`),
  ADD CONSTRAINT `trip_ibfk_4` FOREIGN KEY (`assistant_id`) REFERENCES `assistant` (`assistant_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
